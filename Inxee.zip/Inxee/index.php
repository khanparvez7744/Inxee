<?php include('header-first.php') ?>
<title>Inxee Systems Private Limited - IoT | Hardware & Software | Embedded Electronics | Semiconductors</title>
<meta name="Description"
    content="Building and deploying IoT applications and services that are intelligent, secure and ubiquitous." />
<meta name="keywords"
    content="Gwatch, GPS Tracking Smart Watch, Internet Of Things, IoT, IoT Applications, Embedded Electronics, Embedded Eystems, Embedded Hardware, Embedded Software, R&D Services for Product Development, FPGA India, VLSI India, MSME, Embedded Electronics, IoT Industry, ESDM Industry, Indian Embedded Electronics, Smart Cities, Smart Solutions" />
<?php include('header-second.php') ?>
<div class="responsivegrid aem-GridColumn aem-GridColumn--default--12">
    <div class="aem-Grid aem-Grid--12 aem-Grid--default--12">
        <div class="freeflowhtml aem-GridColumn aem-GridColumn--default--12">
            <section id="hero_slider">
                <article class="container-fluid">
                    <div class="row">
                        <div>
                            <div class="item">
                                <div class="repeated-css bg-sapphire-dark">
                                    <img id="changeBnr" src="images/inxee-banner.jpg" class="slide-image" alt="inxee">
                                </div>
                                <div class="slider-overlay-black"></div>
                                <div class="caption">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-2 col-md-2 col-sm-2"></div>
                                            <div class="col-lg-8 col-md-8 col-sm-8">
                                                <h1 class="h2-heading white-color mb-xs-10">Smart City
                                                    Solutions for Smart
                                                    Communities !</h1>
                                                <a href="#" class="btn btn-shutter-more text-uppercase">Read
                                                    More</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </article>
            </section>
        </div>
        <div class="freeflowhtml aem-GridColumn aem-GridColumn--default--12 aboutSection">
            <section>
                <h2 class="mb20 mb-xs-10 text-center">About Us</h2>
                <p class="text-justify"> Inxee Systems Pvt Ltd is an embedded
                    technology-centric Design House and Manufacturing company head-quartered in
                    Delhi-NCR, India. Inxee has completed many successful projects in the domains of
                    Automation, Automotive, Medical, Consumer and Defense Electronics. Inxee is
                    currently creating products and executing turn-key projects in various Internet Of
                    Things (IoT) applications such as – Smart City, Smart Home, Smart Factory, Smart
                    Healthcare and Smart Wearables/Trackers.</p>
                <p class="text-justify">Inxee is creating waves in the Embedded-IoT Technology R&D
                    services and product
                    landscape, and has designed, manufactured and deployed embedded hardware and
                    software products that are reliable. We at Inxee believe that the Internet Of Things
                    is bringing a transformational shift to the world as we know. IoT has the potential
                    to be the engine that powers our economy for decades to come. We now build IoT
                    products and provide services to partners to help deliver IoT solutions that are
                    reliable, intelligent and ubiquitous. With the IoT market demanding fast development
                    and deployment cycles, Inxee is shedding traditional industry practices and putting
                    together generic IoT solutions in the form of SMART PCB modules, that can be quickly
                    customized to the target applications.</p>
                <p class="text-justify">Inxee offers a broad spectrum of solutions in design &
                    development under the fields
                    of PCB, Embedded Software & Systems. Inxee provides design, manufacturing,
                    installation and maintenance services support to its partners with its services
                    spanning across individual hardware and software components to entire systems. We
                    are experts in an array of embedded platforms -- hardware technologies and embedded
                    programming skill sets.</p>
            </section>
        </div>
        <div class="freeflowhtml aem-GridColumn aem-GridColumn--default--12 ">
            <section id="aviation" class="aviationBg scroll-section relative bg-topaz-medium home_promo_banner">
                <article class="container">
                    <div class="row">
                        <div class="content home-second-heading-top wow fadeInUp" data-wow-delay="0.3s">
                            <div class="col-lg-1 col-md-1 col-sm-1 col-xs-12"></div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 bgTransHalf">
                                <h2 class="home-second-heading white-color mb20 mb-xs-10">Aviation</h2>
                                <p class="fullpage-desc white-color text-justify">
                                    Aviation began in the 18th century with the development of the hot
                                    air balloon, an apparatus capable of atmospheric displacement
                                    through buoyancy. Some of the most significant advancements in
                                    aviation technology came with the controlled gliding flying of Otto
                                    Lilienthal in 1896; then a large step in significance came with the
                                    construction of the first powered.</em></p>
                                <p class=""> <a href="#" aria-label="Explore Digital Core Capabilities" title="Explore"
                                        class="btn btn-shutter-more text-uppercase fontweight600">Explore</a>
                                </p>

                            </div>
                        </div>
                    </div>
                    <div class="background fullCoverImg ai-powered-core-img dnf-digital-capabilities-lead">
                    </div>
                </article>
            </section>
        </div>
        <div class="freeflowhtml aem-GridColumn aem-GridColumn--default--12">
            <section id="automation" class="scroll-section relative bg-sapphire-medium home_promo_banner">
                <article class="container">
                    <div class="row">
                        <div class="content home-third-heading-top">
                            <div class="bgTransHalf col-lg-6 col-md-6 col-sm-6 col-sm-offset-5 col-xs-12 wow fadeInUp"
                                data-wow-delay="0.3s">
                                <h2 class="home-second-heading white-color mb20 mb-xs-10">Automation
                                </h2>
                                <p class="fullpage-desc white-color text-justify"> Automation describes
                                    a wide range of technologies that reduce human intervention in
                                    processes, namely by predetermining decision criteria, subprocess
                                    relationships, and related actions, as well as embodying those
                                    predeterminations in machines.[1] Automation has been achieved by
                                    various means including mechanical, hydraulic, pneumatic,
                                    electrical.</p>
                                <p class=""> <a href="#" aria-label="Explore Digital Operating Models" title="Explore"
                                        class="btn btn-shutter-more text-uppercase fontweight600">Explore</a>
                                </p>

                            </div>
                            <div class="col-lg-1 col-md-1 col-sm-1 col-xs-12"></div>
                        </div>
                    </div>
                    <div class="background fullCoverImg-left agile-digital-bg-img dnf-digital-operating-lead">
                    </div>
                </article>
            </section>
        </div>
        <div class="freeflowhtml aem-GridColumn aem-GridColumn--default--12">
            <section id="medical" class="scroll-section relative bg-medical-medium home_promo_banner">
                <article class="container">
                    <div class="row">
                        <div class="content home-second-heading-top">
                            <div class="col-lg-1 col-md-1 col-sm-1 col-xs-12"></div>
                            <div class="bgTransHalf col-lg-6 col-md-6 col-sm-6 col-xs-12 wow fadeInUp animateFirst"
                                data-wow-delay="0.3s">
                                <h2 class="home-second-heading white-color mb20 mb-xs-10">Medical Electronics</h2>
                                <p class="fullpage-desc white-color text-justify"> An original equipment
                                    manufacturer (OEM) is generally perceived as a company that produces
                                    non-aftermarket[1] parts and equipment that may be marketed by
                                    another manufacturer. It is a common industry term recognized and
                                    used by many professional organizations such as SAE
                                    International,[2] ISO,[3] and others. However, the term is also used
                                    in several other ways, which causes ambiguity.</p>
                                <p class=""> <a href="#" aria-label="Explore Empowering Talent Transformations"
                                        title="Explore"
                                        class="btn btn-shutter-more text-uppercase fontweight600">Explore</a>
                                </p>

                            </div>
                        </div>
                    </div>
                    <div class="background fullCoverImg learn-bg-img dnf-talent-transformations-lead">
                    </div>
                </article>
            </section>
        </div>
        <div class="freeflowhtml aem-GridColumn aem-GridColumn--default--12">
            <section id="defence" class="scroll-section relative bg-defence-medium home_promo_banner">
                <article class="container">
                    <div class="row">
                        <div class="content home-third-heading-top">
                            <div class="bgTransHalf col-lg-6 col-md-6 col-sm-6 col-sm-offset-5 col-xs-12 wow fadeInUp"
                                data-wow-delay="0.3s">
                                <h2 class="home-second-heading white-color mb20 mb-xs-10">Defence
                                    Electronics</h2>
                                <p class="fullpage-desc white-color text-justify"> Medical Electronics
                                    describes a wide
                                    range of technologies that reduce human intervention in processes,
                                    namely by predetermining decision criteria, subprocess
                                    relationships, and related actions, as well as embodying those
                                    predeterminations in machines.[1] Automation has been achieved by
                                    various means including mechanical, hydraulic, pneumatic,
                                    electrical.</p>
                                <p class=""> <a href="#" aria-label="Explore Digital Operating Models" title="Explore"
                                        class="btn btn-shutter-more text-uppercase fontweight600">Explore</a>
                                </p>

                            </div>

                        </div>
                    </div>
                    <div class="background fullCoverImg-left agile-digital-bg-img dnf-digital-operating-lead">
                    </div>
                </article>
            </section>
        </div>
        <div class="freeflowhtml aem-GridColumn aem-GridColumn--default--12">
            <section id="consumer" class="scroll-section relative bg-consumer-medium home_promo_banner">
                <article class="container">
                    <div class="row">
                        <div class="content home-second-heading-top">
                            <div class="col-lg-1 col-md-1 col-sm-1 col-xs-12"></div>
                            <div class="bgTransHalf col-lg-6 col-md-6 col-sm-6 col-xs-12 wow fadeInUp animateFirst"
                                data-wow-delay="0.3s">
                                <h2 class="home-second-heading white-color mb20 mb-xs-10">Consumer Electronics</h2>
                                <p class="fullpage-desc white-color text-justify"> An original equipment
                                    manufacturer (OEM) is generally perceived as a company that produces
                                    non-aftermarket[1] parts and equipment that may be marketed by
                                    another manufacturer. It is a common industry term recognized and
                                    used by many professional organizations such as SAE
                                    International,[2] ISO,[3] and others. However, the term is also used
                                    in several other ways, which causes ambiguity.</p>
                                <p class=""> <a href="#" aria-label="Explore Empowering Talent Transformations"
                                        title="Explore"
                                        class="btn btn-shutter-more text-uppercase fontweight600">Explore</a>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="background fullCoverImg learn-bg-img dnf-talent-transformations-lead">
                    </div>
                </article>
            </section>
        </div>
        <div class="freeflowhtml aem-GridColumn aem-GridColumn--default--12">
            <section id="oem" class="scroll-section relative bg-amethyst-medium home_promo_banner">
                <article class="container">
                    <div class="row">
                        <div class="content home-third-heading-top">
                            <div class="bgTransHalf col-lg-6 col-md-6 col-sm-6 col-sm-offset-5 col-xs-12 wow fadeInUp"
                                data-wow-delay="0.3s">
                                <h2 class="home-second-heading white-color mb20 mb-xs-10">
                                    Electronics OEM/ODM</h2>
                                <p class="fullpage-desc white-color text-justify"> Medical Electronics
                                    describes a wide
                                    range of technologies that reduce human intervention in processes,
                                    namely by predetermining decision criteria, subprocess
                                    relationships, and related actions, as well as embodying those
                                    predeterminations in machines.[1] Automation has been achieved by
                                    various means including mechanical, hydraulic, pneumatic,
                                    electrical.</p>
                                <p class=""> <a href="#" aria-label="Explore Digital Operating Models" title="Explore"
                                        class="btn btn-shutter-more text-uppercase fontweight600">Explore</a>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="background fullCoverImg-left agile-digital-bg-img dnf-digital-operating-lead">
                    </div>
                </article>
            </section>
        </div>
        <div class="freeflowhtml aem-GridColumn aem-GridColumn--default--12">
            <div class="left-navigation relative">
                <nav class="sticky-left-nav top-menu">

                    <ul class="stick-left-nav-ul">
                        <li>
                            <a href="#aviation" class="aviationLi">
                                <span>AVIATION</span></a>
                        </li>
                        <li>
                            <a href="#automation" class="automationLi">
                                <span>AUTOMATION</span></a>
                        </li>
                        <li class="no-scrollify">
                            <a href="#medical" class=" medicalLi">
                                <span>MEDICAL ELECTRONICS</span></a>
                        </li>
                        <li class="no-scrollify">
                            <a href="#defence" class="defenceLi">
                                <span>DEFENCE ELECTRONICS</span></a>
                        </li>
                        <li class="no-scrollify">
                            <a href="#consumer" class="consumerLi">
                                <span>CONSUMER ELECTRONICS</span></a>
                        </li>
                        <li>
                            <a href="#oem" class="oemLi">
                                <span>ELECTRONICS OEM/ODM</span></a>
                        </li>
                    </ul>
                </nav>
            </div>

        </div>
        <div class="freeflowhtml aem-GridColumn aem-GridColumn--default--12">
            <img src="images/down-arrow-inxee.png" alt="arrow" class="arrowFixed">
        </div>
    </div>
</div>
<?php include('footer.php') ?>