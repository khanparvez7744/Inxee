-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2023 at 07:20 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inxee`
--

-- --------------------------------------------------------

--
-- Table structure for table `career`
--

CREATE TABLE `career` (
  `id` int(255) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` int(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `notice` varchar(50) NOT NULL,
  `resume` varchar(50) NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `career`
--

INSERT INTO `career` (`id`, `name`, `email`, `phone`, `location`, `notice`, `resume`, `created_at`) VALUES
(11, 'Abhishek Mishra', 'abhishek@inxee.com', 2147483647, 'gurgaon', '30 days', 'parvez.jpg', '2023-03-14'),
(12, 'aman', 'aman@inxee.com', 2147483647, 'gurgaon', '30 days', 'parvez.jpg', '2023-03-14'),
(13, 'iqra', 'iqra@inxee.com', 2147483647, 'gurgaon', '30 days', 'srinath.jpg', '2023-03-14'),
(14, 'a', 'a@a', 0, 'a', 'a', '', '2023-03-15'),
(15, 'chunna', 'chunna@chunna', 0, 'chunna', 'chunna', 'career3.png', '2023-03-15'),
(16, 'javed', 'khanparvez7744@gmail.com', 2147483647, 'a', 'a', 'careers2.png', '2023-03-15'),
(17, 'sultan', 'sultan@sultan', 0, 'sultan', 'sultan', 'career1.png', '2023-03-15'),
(18, '1111111111', '1111111111@1111111111', 1111111111, '1111111111', '1111111111', 'parvez.jpg', '2023-03-15');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(255) NOT NULL,
  `name` varchar(50) NOT NULL,
  `company` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` int(50) NOT NULL,
  `message` varchar(1000) NOT NULL,
  `create_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `company`, `email`, `phone`, `message`, `create_at`) VALUES
(1, 'parvez', 'inxee', 'khanparvez7744@gmail.com', 2147483647, 'testing', '2023-03-14'),
(3, 'Amit', 'inxee systmes', 'amit@gmail.com', 2147483647, 'test', '2023-03-14'),
(4, 'aman', 'inxee systmes', 'aman@inxee.com', 2147483647, 'test', '2023-03-14'),
(5, 'sdsdsdsdsdsdsdssds', 'sdsdsdsds', 'sdsdsdsd@sdsd', 0, 'sdsdsdsd', '2023-03-15'),
(6, 'a', 'a', 'a@a', 0, '', '2023-03-15'),
(7, 'insha', 'insha', 'insha@insha', 0, 'insha', '2023-03-15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `career`
--
ALTER TABLE `career`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `career`
--
ALTER TABLE `career`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
