<?php include('header-first.php') ?>
<title>Press Release – IoT | Design In India. Make In India | Inxee Systems Private Limited</title>
<meta name="Description"
    content="Inxee builds IoT applications and services that are smart, intelligent and ubiquitous." />
<meta name="keywords"
    content="internet of things, iot, embedded india, india embedded, indian embedded electronics, embedded software india" />
<?php include('header-second.php') ?>
<section class="banner-section">
    <img src="images/Pres release.jpg" alt="Pres release" class="img-responsive">
</section>
<section class="common-section py-3">
    <div class="container">
        <h1 class="mb-3">Press Release</h1>
        <h2 class="mb-3">Mr. Srinath Nudurupati Addresses Conference Session on Day2 - 2nd India IoT Expo 2018:</h2>
        <ol>
            <li>Amity University Felicitates Mr. Srinath Nudurupati with "Amity Entrepreneurial Excellence Award</li>
            <li>Dronacharya College Of Engineering, Visits Inxee For An Industrial Tour</li>
        </ol>
        <h2 class="mb-3 mt-3">Inxee Wins At The ELCINA-EFY Awards 2017:</h2>
        <ol>
            <li>Inxee Participates At The IPCA Electronics Expo-2017. Here's the sneak peek!</li>
            <li>EFY Magazine's Interview With Our Director Mr.Nate Nudurupati
            </li>

        </ol>
        <h2 class="mb-3 mt-3">EFY 2016:</h2>
        <ol>
            <li>A Report On Media Processors. Contributions by Mr.Nate Srinath</li>
        </ol>
        <h2 class="mb-3 mt-3">EFY 2015:</h2>
        <ol>
            <li>INXEE's And Binary Semantics's Joint Venture - Fleet RoBo
            </li>
            <li>INXEE at EFY 2015- Press Release
            </li>
            <li>Mr.Nate Srinath, founder-INXEE, shares his insights on the processor selection for Embedded Systems</li>
            <li>INXEE Prepares For Electonics For You Expo - Press Release</li>
        </ol>
        <h2 class="mb-3 mt-3">EFY 2014:</h2>
        <ol>
            <li>EFY 2014 - Mr. Srinath,Director-Inxee, shares his thoughts at EFY</li>
            <li>INXEE- The technical part of Fleet Robo
            </li>
        </ol>
    </div>
</section>
<?php include('footer.php') ?>