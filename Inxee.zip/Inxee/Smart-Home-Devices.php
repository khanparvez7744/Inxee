<?php include('header-first.php') ?>
<title>Smart Home Devices - IoT | Design In India. Make In India | Inxee Systems Private Limited</title>
<meta name="Description"
    content="Inxee has taken up projects which caters to various parts of Smart and Connected Cities." />
<meta name="keywords" content="smart homes, smart home devices, smart solutions, internet of things, iot" />
<?php include('header-second.php') ?>
<section class="banner-section">
    <img src="images/Smart-home-banner.jpg" alt="smart home" class="img-responsive">
</section>
<section class="common-section py-3">
    <div class="container">
        <h1 class="mb-3">Smart Home Devices</h1>
        <p class="text-justify">Any Home becomes smart if it can provide its
            occupants security, comfort, efficient energy consumption, low
            operational expenditure and convenience round the clock,
            irrespective of the fact whether anybody is physically at home
            or not. Our Smart Home solutions are generic that are compatible
            with many IoT platforms along with ease in setup, maintenance,
            reliability and assured high quality</p>
        <p class="text-justify">The appliances used in smart homes for lighting, air conditioning, water purification
            and supply, entertainment, security purposes should be designed such that they are able to communicate among
            themselves and be controlled remotely from any location across the globe just by being connected to the
            internet via smart peripherals.</p>

    </div>
</section>
<?php include('footer.php') ?>