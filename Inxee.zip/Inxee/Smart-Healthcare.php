<?php include('header-first.php') ?>
<title>Smart Healthcare - IoT | Design In India. Make In India | Inxee Systems Private Limited</title>
<meta name="Description"
    content="Inxee has taken up projects which caters to various parts of Smart and Connected Cities." />
<meta name="keywords" content="smart homes, smart home devices, smart solutions, internet of things, iot" />
<?php include('header-second.php') ?>
<section class="banner-section">
    <img src="images/Smart-Healthcare.jpg" alt="smart Healthcare" class="img-responsive">
</section>
<section class="common-section py-3">
    <div class="container">
        <h1 class="mb-3">Smart Healthcare</h1>
        <p class="text-justify">The Internet Of Things is already helping bring revolutionary concepts to ensure
            constructive development of the healthcare industry that can eventually bring about three key benefits for
            health care services : quality of monitoring, better accessibility, improved access to care and maintenance.
        </p>
        <p class="text-justify">Many cloud-connected devices and user-friendly softwares have been introduced at various
            stages to patients and people in general that would help ease daily monitoring required in the healthcare
            industry. Irrespective of the source from where data is collected , be it the readings of a temperature
            monitor, fetal monitor, electrocardiogram or blood glucose level monitor - you can always keep yourself
            updated, and on the move. Keeping a tab on health should always be your prime concern and with the foray of
            IoT in the same field, things have started to become easier and smarter. This would also reduce the need for
            human intervention and physical one-on-one.</p>

    </div>
</section>
<?php include('footer.php') ?>