<?php include('header-first.php') ?>
<title>Smart Wearables - IoT | Design In India. Make In India | Inxee Systems Private Limited</title>
<meta name="Description"
    content="Inxee has taken up projects which caters to various parts of Smart and Connected Cities." />
<meta name="keywords" content="smart homes, smart home devices, smart solutions, internet of things, iot" />
<?php include('header-second.php') ?>
<section class="banner-section">
    <img src="images/Smart-Wearables.jpg" alt="smart Wearables" class="img-responsive">
</section>
<section class="common-section py-3">
    <div class="container">
        <h1 class="mb-3">Smart Wearables</h1>
        <p class="text-justify">Often touted as one of the most significant applications of the Internet of Things, and
            with good reasons, wearable technology has opened up a plethora of avenues for research and development and
            there is no end to the applications that can follow.</p>
        <p class="text-justify">Fitness and health oriented wearables often offer biometric measurements such as heart
            rate, pulse rate, perspiration and at times complex measurements like oxygen or haemoglobin in the
            bloodstream are slowly getting available. Such technology advancements might even help monitor alcohol
            levels and other similar computations via wearable technology.</p>
        <p class="text-justify">The wearable domain is already one of the top catalysts to push the IoT device market
            towards these heights. The ability to sense, store, and track biometric measurements time and again for
            proper treatment and monitoring itself has opened up a plethora of application and solution development
            avenues.</p>

    </div>
</section>
<?php include('footer.php') ?>