$(document).ready(function () {
    $(".aviationLi").mouseover(function () {
        $('#changeBnr').attr("src", "images/aviation-pk.jpg");
    });
    $(".aviationLi").mouseout(function () {
        $('#changeBnr').attr("src", "images/inxee-banner.jpg");
    });
    $(".automationLi").mouseover(function () {
        $('#changeBnr').attr("src", "images/automation-pk.jpg");
    });
    $(".automationLi").mouseout(function () {
        $('#changeBnr').attr("src", "images/inxee-banner.jpg");
    });
    $(".medicalLi").mouseover(function () {
        $('#changeBnr').attr("src", "images/medical-pk.jpg");
    });
    $(".medicalLi").mouseout(function () {
        $('#changeBnr').attr("src", "images/inxee-banner.jpg");
    });
    $(".defenceLi").mouseover(function () {
        $('#changeBnr').attr("src", "images/defence-pk.jpg");
    });
    $(".defenceLi").mouseout(function () {
        $('#changeBnr').attr("src", "images/inxee-banner.jpg");
    });
    $(".consumerLi").mouseover(function () {
        $('#changeBnr').attr("src", "images/consumer-pk.jpg");
    });
    $(".consumerLi").mouseout(function () {
        $('#changeBnr').attr("src", "images/inxee-banner.jpg");
    });
    $(".oemLi").mouseover(function () {
        $('#changeBnr').attr("src", "images/oemodm-pk.jpg");
    });
    $(".oemLi").mouseout(function () {
        $('#changeBnr').attr("src", "images/inxee-banner.jpg");
    });
});
// start sticky header
$(function () {
    $(window).scroll(function () {
        var winTop = $(window).scrollTop();
        if (winTop >= 30) {
            $("body").addClass("sticky-header");
        } else {
            $("body").removeClass("sticky-header");
        }
    });
});
// end sticky header