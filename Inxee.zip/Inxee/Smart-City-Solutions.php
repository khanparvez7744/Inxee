<?php include('header-first.php') ?>
<title>Smart City Solutions - IoT | Design In India. Make In India | Inxee Systems Private Limited</title>
<meta name="Description"
    content="Inxee has taken up projects which caters to various parts of Smart and Connected Cities." />
<meta name="keywords" content="smart cities, smart solutions, internet of things, iot" />
<?php include('header-second.php') ?>
<section class="banner-section">
    <img src="images/solution-banner.jpg" alt="solution" class="img-responsive">
</section>
<section class="common-section py-3">
    <div class="container">
        <h1 class="mb-3">Smart City Solutions</h1>
        <p class="text-justify">Inxee has taken up projects which caters to various parts of Smart and Connected Cities.
            Inxee is keen to work with its partners for support in the initiative of developing Smart and Connected
            Cities to embark upon a brighter and sustainable future.
        </p>

        <h2 class="mb-2 mt-3">Our Smart City Verticals:</h2>
        <ol>
            <li>Building Management Systems</li>
            <li>Smart Water Meter</li>
            <li>Smart Parking</li>
            <li>Smart Metering</li>
            <li>Intelligent Transportation System</li>
            <li>Smart Tags</li>
            <li>Smart Energy</li>
            <li>Smart Street Lighting</li>

        </ol>
        <p class="text-justify">We also comply by the latest communication protocols used in both wired and wireless
            data transmission that are listed as below:
        </p>
        <h2 class="mb-2 mt-3">Wireless -</h2>
        <ol>
            <li>Blutooth</li>
            <li>LoRa</li>
            <li>SigFox</li>
            <li>ZigBig</li>
            <li>6LoWPAN</li>
            <li>WiFi DECT</li>
            <li>ULE 2G/3G/4G</li>
            <li>en Ocean</li>
            <li>Z-Wave</li>

        </ol>
        <h2 class="mb-2 mt-3">Wired -</h2>
        <ol>
            <li>Lon Works</li>
            <li>P1901.2</li>
            <li>SigFox</li>
            <li>G3-PLC</li>
            <li>Home Plug</li>
            <li>M-Bus</li>
            <li>IO-Homecontrol</li>
            <li>KNX Smart</li>
            <li>Ethernet Integration</li>

        </ol>

    </div>
</section>
<?php include('footer.php') ?>