<script>
(function(i, s, o, g, r, a, m) {
    i['GoogleAnalyticsObject'] = r;
    i[r] = i[r] || function() {
        (i[r].q = i[r].q || []).push(arguments)
    }, i[r].l = 1 * new Date();
    a = s.createElement(o),
        m = s.getElementsByTagName(o)[0];
    a.async = 1;
    a.src = g;
    m.parentNode.insertBefore(a, m)
})(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

ga('create', 'UA-63733126-3', 'auto');
ga('send', 'pageview');
</script>
<link rel="shortcut icon" href="images/favicon.png">
<script src="css2/infosys-web/clientlibs/clientlib-dependencies.js"></script>
<link rel="stylesheet" href="css2/infosys-web/clientlibs/clientlib-commons.css" type="text/css">
<link rel="stylesheet" href="css2/infosys-web/clientlibs/clientlib-base.css" type="text/css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" />
<link rel="stylesheet" href="css/inxee.css">
</head>

<body class="page basepage basicpage ">
    <div>
        <div class="root responsivegrid">
            <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
                <div class="pagedetails parbase aem-GridColumn aem-GridColumn--default--12"></div>
                <div class="header aem-GridColumn aem-GridColumn--default--12">
                    <header>
                        <div class="row">
                            <div class="col-sm-2">
                                <a href="index.php">
                                    <img src="images/inxee-logo.png" alt="logo" class="logoInx">
                                </a>
                            </div>
                            <div class="col-sm-10">
                                <!-- start custom nav -->
                                <nav class="navTag">
                                    <ul class="navInx">
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="javascript:void(0)">Overview</a>
                                            <ul>
                                                <li><a href="about-us.php">About Us</a></li>
                                                <li><a href="leadership.php">Leadership</a></li>
                                                <li><a href="company-philosophy.php">Company Philosophy</a></li>
                                                <li><a href="clients-alliances.php">Clients & Alliances</a></li>
                                                <li><a href="projects-achievements.php">Projects & Achievements</a></li>
                                                <li><a href="career-with-us.php">Career With Us</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="javascript:void(0)">Our IOT Verticals</a>
                                            <ul>
                                                <li><a href="Smart-City-Solutions.php">Smart City Solutions</a></li>
                                                <li><a href="Smart-Home-Devices.php">Smart Home Devices</a></li>
                                                <li><a href="Smart-Automation.php">Smart Automation</a></li>
                                                <li><a href="Smart-Healthcare.php">Smart Healthcare</a></li>
                                                <li><a href="Smart-Wearables.php">Smart Wearables</a></li>
                                                <li><a href="Smart-Tracking-Solutions.php">Smart Tracking Solutions</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li><a href="javascript:void(0)">Our Services</a>
                                            <ul>
                                                <li><a href="pcba-design-and-development.php">PCBA Design &
                                                        Development</a></li>
                                                <li><a href="embedded-software.php">Embedded Software</a></li>
                                                <li><a href="embedded-devices.php">Embedded Devices</a></li>
                                                <li><a href="cloud-server-applications.php">Cloud Server &
                                                        Applications</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="javascript:void(0)">Resources</a>
                                            <ul>
                                                <li><a target="_blank" href="http://inxee.com/blog">Blog </a>
                                                </li>
                                                <li><a href="press-release.php">Press Release</a></li>
                                                <li><a href="news-events.php">News and Events</a></li>
                                            </ul>
                                        </li>

                                    </ul>
                                </nav>
                                <!-- end custom nav -->
                            </div>
                        </div>

                    </header>
                </div>
                <div class="experiencefragment aem-GridColumn aem-GridColumn--default--12">
                    <div class="xf-content-height">
                        <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
                            <div class="freeflowhtml aem-GridColumn aem-GridColumn--default--12">
                                <link href="css3/dam/infosys-web/burger-menu/en/css/burger-menu.css" rel="stylesheet">
                                <!-- start right sidebar -->
                                <div class="burger-search-wrapper navbar-fixed-top">
                                    <div class="container">
                                        <nav class="hamburger-menu" role="main nav" aria-label="open menu">
                                            <div class="menu-bg"></div>
                                            <div class="circle"></div>
                                            <a href="javascript:void(0);" class="burger" aria-label="open menu"
                                                aria-haspopup="false" aria-expanded="false">
                                                <div class="icon-bar1"></div>
                                                <div class="icon-bar2"></div>
                                                <div class="icon-bar3"></div>
                                            </a>
                                            <div class="menu">
                                                <div
                                                    class="fix-menu hidden-sm hidden-xs col-md-9 col-sm-12 col-xs-12 p0">
                                                </div>
                                                <!-- Side Menu Title -->
                                                <div class="col-md-3 col-sm-12 col-xs-12 menuItems"> <a href="index.php"
                                                        title="" aria-label=""> <img src="images/inxee-logo.png"
                                                            alt="logo" style="width:130px"
                                                            class="img-responsive logo-inner"> </a>
                                                    <ul class="list-unstyled servicInxe">
                                                        <li class="smalltext">
                                                            <a href="about-us.php">About Us</a>
                                                        </li>
                                                        <li class="smalltext">
                                                            <a href="leadership.php">Leadership</a>
                                                        </li>
                                                        <li class="smalltext">
                                                            <a href="company-philosophy.php">Company Philosophy</a>
                                                        </li>
                                                        <li class="smalltext">
                                                            <a href="clients-alliances.php">Clients & Alliances</a>
                                                        </li>
                                                        <li class="smalltext">
                                                            <a href="projects-achievements.php">Projects &
                                                                Achievements</a>
                                                        </li>
                                                        <li class="smalltext">
                                                            <a href="career-with-us.php">Career With Us</a>
                                                        </li>
                                                        <li class="smalltext">
                                                            <a href="Smart-City-Solutions.php">Smart City Solution</a>
                                                        </li>
                                                        <li class="smalltext">
                                                            <a href="Smart-Home-Devices.php">Smart Home Devices</a>
                                                        </li>
                                                        <li class="smalltext">
                                                            <a href="Smart-Automation.php">Smart Automation</a>
                                                        </li>
                                                        <li class="smalltext">
                                                            <a href="Smart-Healthcare.php">Smart Healthcare</a>
                                                        </li>
                                                        <li class="smalltext">
                                                            <a href="Smart-Wearables.php">Smart Wearables</a>
                                                        </li>
                                                        <li class="smalltext">
                                                            <a href="Smart-Tracking-Solutions.php">Smart Tracking
                                                                Solution</a>
                                                        </li>
                                                        <li class="smalltext">
                                                            <a href="pcba-design-and-development.php">PCBA Design &
                                                                Development</a>
                                                        </li>
                                                        <li class="smalltext">
                                                            <a href="embedded-software.php">Embedded Software</a>
                                                        </li>
                                                        <li class="smalltext">
                                                            <a href="embedded-devices.php">Embedded Devices</a>
                                                        </li>
                                                        <li class="smalltext">
                                                            <a href="cloud-server-applications.php">Cloud Server &
                                                                Application</a>
                                                        </li>
                                                        <li class="smalltext">
                                                            <a href="http://inxee.com/blog/">Blog</a>
                                                        </li>
                                                        <li class="smalltext">
                                                            <a href="press-release.php">Press Release</a>
                                                        </li>
                                                        <li class="smalltext">
                                                            <a href="news-events.php">News & Events</a>
                                                        </li>

                                                    </ul>
                                                </div>

                                            </div>
                                        </nav>
                                    </div>
                                </div>
                                <!-- end right sidebar -->
                                <script src="css3/dam/infosys-web/burger-menu/en/js/burger-menu.js"></script>
                            </div>
                        </div>
                    </div>
                </div>