<div class="experiencefragment aem-GridColumn aem-GridColumn--default--12">
    <div class="xf-content-height">
        <div class="aem-Grid aem-Grid--12 aem-Grid--default--12 ">
            <div class="freeflowhtml aem-GridColumn aem-GridColumn--default--12">
                <footer id="footer">
                    <article>
                        <div class="container pt50 pb50">
                            <div class="row">
                                <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
                                    <h3 class="ftr-head mt-xs-20">Overview</h3>
                                    <ul class="list-unstyled footer-txt">
                                        <li><a href="about-us.php" title="About Us">About Us</a></li>
                                        <li><a href="leadership.php" title="Leadership">Leadership</a></li>
                                        <li><a href="company-philosophy.php" title="Company Philosophy">Company
                                                Philosophy</a></li>
                                        <li><a href="clients-alliances.php" title="Clients & Alliances">Clients &
                                                Alliances</a></li>
                                        <li><a href="projects-achievements.php" title="Projects & Achievements">Projects
                                                & Achievements</a>
                                        </li>
                                        <li><a href="career-with-us.php" title="Career With Us">Career With Us</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12">
                                    <h3 class="ftr-head mt-xs-20">IoT Verticals</h3>
                                    <ul class="list-unstyled footer-txt">
                                        <li><a href="Smart-City-Solutions.php" title="Smart City Solutions">Smart City
                                                Solutions</a> </li>
                                        <li><a href="Smart-Home-Devices.php" title="Smart Home Devices">Smart Home
                                                Devices</a></li>
                                        <li><a href="Smart-Automation.php" title="Smart Automation">Smart Automation</a>
                                        </li>
                                        <li><a href="Smart-Healthcare.php" title="Smart Healthcare">Smart Healthcare</a>
                                        </li>
                                        <li><a href="Smart-Wearables.php" title="Smart Wearables">Smart Wearables</a>
                                        </li>
                                        <li><a href="Smart-Tracking-Solutions.php"
                                                title="Smart Tracking Solutions">Smart Tracking Solutions</a></li>
                                    </ul>
                                </div>
                                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                                    <h3 class="ftr-head mt-xs-20">Services</h3>
                                    <ul class="list-unstyled footer-txt">
                                        <li><a href="pcba-design-and-development.php"
                                                title="PCBA Design & Development">PCBA Design & Development</a></li>
                                        <li><a href="embedded-software.php" title="Embedded  Software">Embedded
                                                Software</a></li>
                                        <li><a href="embedded-devices.php" title="Embedded Devices">Embedded Devices</a>
                                        </li>
                                        <li><a href="cloud-server-applications.php"
                                                title="Cloud Server and Applications">Cloud Server and Applications</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="clearfix visible-sm"></div>
                                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                                    <h3 class="ftr-head mt-xs-20">Resources</h3>
                                    <ul class="list-unstyled footer-txt">
                                        <li><a href="http://inxee.com/blog" target="_blank" title="Blog Section">Blog
                                            </a></li>
                                        <li><a href="press-release.php" title="Press Releases">Press
                                                Releases</a></li>
                                        <li><a href="news-events.php" title="News and Events">News
                                                and Events</a></li>
                                        <li><a href="contact-us.php" title="Contact Us">Contact
                                                Us</a></li>
                                        <li><a href="faq.php" title="FAQ">FAQ</a>
                                        </li>
                                        <li><a href="sitemap.php" title="Sitemap">Sitemap</a></li>
                                    </ul>
                                </div>
                                <div class="col-lg-2 col-md-6 col-sm-6 col-xs-12">
                                    <h3 class="ftr-head mt-sm-20">Connect with us</h3>
                                    <ul class="list-inline footer-txt">
                                        <li>
                                            <a title="Follow us on Twitter" target="_blank"
                                                href="https://twitter.com/inxee_2010"> 
                                                <i class="fab fa-twitter text-muted"></i>
                                                <!-- <img src="images/twitter.svg"
                                                    width="16" height="16" alt="Twitter" /> -->
                                            </a>
                                        </li>
                                        <li>
                                            <a title="Follow us on Facebook" target="_blank"
                                                href="https://www.facebook.com/inxee.systems"> 
                                                <i class="fab fa-facebook-f text-muted"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a title="Follow us on LinkedIn" target="_blank"
                                                href="https://www.linkedin.com/company/inxee-systems"> 
                                                <i class="fab fa-linkedin-in text-muted"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a title="Follow us on Google+" target="_blank"
                                                href="https://accounts.google.com/v3/signin/identifier?dsh=S-2046010439%3A1678363266958159&continue=https%3A%2F%2Fplus.google.com%2F111559072187759368244&followup=https%3A%2F%2Fplus.google.com%2F111559072187759368244&ifkv=AWnogHesxNqoTNtQtNQRGE605Q_etMHbmcdzHMqi2OhDpJWq69Y3EXFWz9zS2wCPJoe_31oesbFaiA&osid=1&passive=1209600&flowName=GlifWebSignIn&flowEntry=ServiceLogin">
                                                <i class="fab fa-google-plus-g text-muted"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="container-fluid ptb15 bg-white">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <p class="mb0 text-center">Copyright © 2017 Inxee.com, All
                                            rights reserved.
                                        </p>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </article>
                </footer>
                <a href="javascript:void(0)" class="scroll-up"> <img src="images/move.webp" alt="Arrow up"
                        class="img-responsive"> </a>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<script src="css2/infosys-web/clientlibs/clientlib-base.js"></script>
</div>
<script src="js/script.js"></script>
</body>

</html>