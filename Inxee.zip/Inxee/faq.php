<?php include('header-first.php') ?>
<title>FAQ – Inxee Systems Private Limited</title>
<meta name="Description"
    content="Inxee has their development centers in Gurgaon - FAQ" />
<meta name="keywords"
    content="embedded india, india embedded, indian embedded electronics, embedded software india" />
<?php include('header-second.php') ?>
<section class="banner-section">
    <img src="images/FAQ.jpg" alt="FAQ" class="img-responsive">
</section>
<section class="common-section faq-section py-3">
    <div class="container">
        <h1 class="mb-3">Frequently Asked Question</h1>
            <div class="panel-group" id="accordion">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#faq1">Q.1 What are the items
                                covered under ESDM sector?</a>
                        </h4>
                    </div>
                    <div id="faq1" class="panel-collapse collapse in">
                        <div class="panel-body">Electronics System Design & Manufacturing sector covers electronic
                            hardware products relating to IT and office automation, telecom, consumer electronics, etc.,
                            It also includes avionics, solar photovoltaic, strategic electronics, nano electronics,
                            medical electronics, space & defence related items, design related activities like product
                            design, chip designing, VLSI-ASIC/FPGA, board design, PCB design, embedded systems etc.
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#faq2">Q.2 What do I gain by
                                ordering the development of an electronic product with INXEE?</a>
                        </h4>
                    </div>
                    <div id="faq2" class="panel-collapse collapse">
                        <div class="panel-body">
                            <ol>
                                <li>Confidentiality of information
                                </li>
                                <li>Complementing the customer's competence with our highly specialized services
                                </li>
                                <li>Transparent development process and weekly reporting
                                </li>
                                <li>Compliance with project deadlines stipulated in the Design Assignment
                                </li>
                                <li>Launching the finished product into production and preparing it for certification
                                </li>
                                <li>Proven risk management practices
                                </li>
                                <li>Technical support for the developed device at all stages of the product's life cycle
                                </li>
                                <li>Flexible business models for cooperation and seamless integration into the
                                    customer’s workforce
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#faq3">Q.3 Who reserves the rights
                                to the intellectual property created in the process of development?</a>
                        </h4>
                    </div>
                    <div id="faq3" class="panel-collapse collapse">
                        <div class="panel-body">
                            <p class="text-justify">We are in tandem with our customers throughout the development cycle of the project. Here are some of the main patterns :</p>
                            <ol>
                                <li>The customer pays for the entire project and receives all the rights for the result
                                    of
                                    the development (source codes, project files and design documentation).
                                </li>
                                <li>Divided intellectual rights for the product.
                                </li>
                                <li>INXEE systems becomes a co-owner of the project and receives royalties on product
                                    sales
                                    or license payments.
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#faq4">Q.4 Who are potential
                                customers for turn-key development projects?</a>
                        </h4>
                    </div>
                    <div id="faq4" class="panel-collapse collapse">
                        <div class="panel-body">
                            <ol>
                                <li>Manufacturers which want to create their own product to diversify their business by
                                    manufacturing electronics and exploring new markets and to protect themselves from
                                    the
                                    risks and increase the share of intellectual property for their products.
                                </li>
                                <li>New companies and business startups which plan to manufacture a prototype for
                                    demonstration to the investor or for the execution of a contract.

                                </li>
                                <li>Industry organizations, suppliers of design documentation as well as small- and
                                    medium-batch products (design, research and development), which want to obtain
                                    design
                                    documentation and workable prototypes within a fixed budget

                                </li>
                                <li>Manufacturers of final equipment and specialized devices, which expand their product
                                    range or replace outdated / imported units


                                </li>
                                <li>Product and technology companies which wish to diversify their business


                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="panel-title">
                            <a data-toggle="collapse" data-parent="#accordion" href="#faq5">Q.5 What is the result of an
                                electronic device development?</a>
                        </h4>
                    </div>
                    <div id="faq5" class="panel-collapse collapse">
                        <div class="panel-body">
                            <ol>
                                <li>Full design documentation for manufacturing the product </li>
                                <li>Softwares source codes </li>
                                <li>Workable enclosure prototypes
                                </li>
                                <li>Recommendations for launching into batch production
                                </li>
                                <li>Opportunities for further technical support

                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
    </div>
</section>
<?php include('footer.php') ?>