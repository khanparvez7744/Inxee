<?php include('header-first.php') ?>
<title>Projects & Achievements - IoT | Design In India. Make In India | Inxee Systems Private Limited</title>
<meta name="Description"
    content="Our effectively prioritized and organized work load distribution to meet targets in an industrial ecosystem. Quality and consistency has often won INXEE accolades from all corners." />
<meta name="keywords"
    content="industrial ecosystem, design & manufacturing services facility, mobile point of sale systems, enabling eco-friendly buildings, video conferencing software development" />
<?php include('header-second.php') ?>
<section class="banner-section">
    <img src="images/Project & Achievements.jpg" alt="Project & Achievements" class="img-responsive">
</section>
<section class="common-section py-3">
    <div class="container">
        <h1 class="mb-3">Projects & Achievements
        </h1>
        <p class="text-justify">We have successfully managed a spectrum of projects from conception through
            implementation. Our effectively prioritized and organized work load distribution to meet targets in an
            industrial ecosystem where change is the only constant has so far seen only favorable and promising
            outcomes. Quality and consistency has often won INXEE accolades from all corners. We are in the process of
            building a tradition of achieving results through our unique blend of industry knowledge, skills and core
            values.
        </p>
        <h2 class="mb-2 mt-3">Listed below are the major projects successfully executed by Inxee under various segments:
        </h2>
        <h3 class="mt-2">Design & Manufacturing:

        </h3>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <td>SEGMENT</td>
                    <td>PRODUCT</td>
                    <td>UTILITY</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Mobiles & Portables </td>
                    <td>Software Development Platform </td>
                    <td>For mobile tablet devices
                    </td>
                </tr>
                <tr>
                    <td>Media</td>
                    <td>Interactive Coffee Tables </td>
                    <td>Dual-touch capable, Rugged for customer order placement, gaming and e-commerce

                    </td>
                </tr>
                <tr>
                    <td>Mobile </td>
                    <td>Mobile Point-of-Sale systems over GSM </td>
                    <td>For Rural Financial Inclusion such as User Authentication based on bio-metric technology

                    </td>
                </tr>
                <tr>
                    <td>Medical</td>
                    <td>Neo-natal / infant Warmer products </td>
                    <td>Will reduce or prevent death caused by Hypothermia in new born babies

                    </td>
                </tr>
                <tr>
                    <td>Wireless / Telecom </td>
                    <td>Single-band and Quad-band Digital Filter systems </td>
                    <td>For GSM, CDMA, 3G, and LTE wireless systems

                    </td>
                </tr>
                <tr>
                    <td>Consumer Electronics </td>
                    <td>3G/LTE WiFi Router </td>
                    <td>Routing with Bluetooth and PSTN connectivity

                    </td>
                </tr>
                <tr>
                    <td>Industrial </td>
                    <td>Green Building Management systems </td>
                    <td>For enabling Eco-Friendly Buildings

                    </td>
                </tr>
                <tr>
                    <td>Industrial Instrumentation </td>
                    <td>Analog & Digital cable TV signal measurement meter </td>
                    <td>For easy signal strength measurement

                    </td>
                </tr>
                <tr>
                    <td>Green Power </td>
                    <td>Solar Lantern & Smart Inverters </td>
                    <td>For proper management of power resources

                    </td>
                </tr>
                <tr>
                    <td>Telecom </td>
                    <td>Gigabit Ethernet switch </td>
                    <td>FPGA based 24 port switch


                    </td>
                </tr>
            </tbody>
        </table>
        <h3>Design & Development:

        </h3>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <td>SEGMENT</td>
                    <td>PRODUCT</td>
                    <td>UTILITY</td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Healthcare </td>
                    <td>Video conferencing software </td>
                    <td>For mobile internet devices in healthcare application

                    </td>
                </tr>
                <tr>
                    <td>Defense</td>
                    <td>Acoustic Noise Cancelling Codec software </td>
                    <td>For TI-DSP based hardware to reduce noise related disruptions


                    </td>
                </tr>
                <tr>
                    <td>Industrial Automation </td>
                    <td>Walk-in Refrigerator control system </td>
                    <td>So that they can cycle on and off to maintain a certain temperature


                    </td>
                </tr>

            </tbody>
        </table>

    </div>
</section>
<?php include('footer.php') ?>