<?php include('header-first.php') ?>
<title>Sitemap Structure – Inxee Systems Private Limited</title>
<meta name="Description"
    content="The complete hierarchy chart of our structure & vision. Get exactly what you were looking for." />
<meta name="keywords"
    content="internet of things, iot, smart wearables, smart trackers, vehicle telematics, smart automation, smart healthcare devices, smart automation, building automation, smart city solutions, embedded india, india embedded, indian embedded electronics, embedded software india" />
<?php include('header-second.php') ?>
<section class="banner-section">
    <img src="images/sitemap.jpg" alt="sitemap" class="img-responsive">
</section>
<section class="common-section py-3">
    <div class="container">
        <h1 class="mb-3">Sitemap</h1>
        <link href="css/sitemap.css" rel="stylesheet" type="text/css">
        <script src="https://code.jquery.com/jquery-2.2.4.min.js"
            integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
        <script src="https://cdn.mysitemapgenerator.com/api/htmlsitemaps.min.js"></script>
        <div class="sitemap">
            <nav class="primaryNav">
                <ul>
                    <li id="home"><a class="black-text" href="index.php"><img
                                src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pg0KPCEtLSBHZW5lcmF0b3I6IEFkb2JlIElsbHVzdHJhdG9yIDE2LjAuMCwgU1ZHIEV4cG9ydCBQbHVnLUluIC4gU1ZHIFZlcnNpb246IDYuMDAgQnVpbGQgMCkgIC0tPg0KPCFET0NUWVBFIHN2ZyBQVUJMSUMgIi0vL1czQy8vRFREIFNWRyAxLjEvL0VOIiAiaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEuZHRkIj4NCjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4PSIwcHgiIHk9IjBweCINCgkgd2lkdGg9IjUxMHB4IiBoZWlnaHQ9IjUxMHB4IiB2aWV3Qm94PSIwIDAgNTEwIDUxMCIgc3R5bGU9ImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgNTEwIDUxMDsiIHhtbDpzcGFjZT0icHJlc2VydmUiPg0KPGc+DQoJPGcgaWQ9ImhvbWUiPg0KCQk8cG9seWdvbiBwb2ludHM9IjIwNCw0NzEuNzUgMjA0LDMxOC43NSAzMDYsMzE4Ljc1IDMwNiw0NzEuNzUgNDMzLjUsNDcxLjc1IDQzMy41LDI2Ny43NSA1MTAsMjY3Ljc1IDI1NSwzOC4yNSAwLDI2Ny43NSANCgkJCTc2LjUsMjY3Ljc1IDc2LjUsNDcxLjc1IAkJIi8+DQoJPC9nPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPGc+DQo8L2c+DQo8Zz4NCjwvZz4NCjxnPg0KPC9nPg0KPC9zdmc+DQo="
                                width="16" height="16" alt="homepage" /> Home</a></li>
                    <li><a class="black-text" href="about-us.php">About Us</a></li>
                    <li><a class="black-text" href="leadership.php">Leadership</a></li>
                    <li><a class="black-text" href="company-philosophy.php">Company Philosophy</a></li>
                    <li><a class="black-text" href="clients-alliances.php">Clients & Alliances</a></li>
                    <li><a class="black-text" href="projects-achievements.php">Projects & Achievements</a></li>
                    <li><a class="black-text" href="Smart-City-Solutions.php">Smart City Solutions</a></li>
                    <li><a class="black-text" href="Smart-Home-Devices.php">Smart Home Devices</a>
                    </li>
                    <li><a class="black-text" href="Smart-Automation.php">Smart Automation</a></li>
                    <li><a class="black-text" href="Smart-Healthcare.php">Smart Healthcare</a></li>
                    <li><a class="black-text" href="Smart-Wearables.php">Smart Wearables</a></li>
                    <li><a class="black-text" href="Smart-Tracking-Solutions.php">Smart Tracking
                            Solutions</a></li>
                    <li><a class="black-text" href="pcba-design-and-development.php">PCBA Design &
                            Development</a>
                    </li>
                    <li><a class="black-text" href="embedded-software.php">Embedded Software</a>
                    </li>
                    <li><a class="black-text" href="embedded-devices.php">Embedded Devices</a>
                    </li>
                    <li><a class="black-text" href="cloud-server-applications.php">Cloud Server &
                            Applications</a>
                    </li>
                    <li><a class="black-text" href="http://inxee.com/blog">Blog </a>
                    </li>
                    <li><a class="black-text" href="press-release.php">Press Releases</a>
                    </li>
                    <li><a class="black-text" href="news-events.php">News and Events</a>
                    </li>
                    <li><a class="black-text" href="career-with-us.php">Career with Us</a>
                    </li>
                    <li><a class="black-text" href="faq.php">FAQ's</a>
                    </li>
                    <li><a class="black-text" href="contact-us.php">Contact Us</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</section>
<?php include('footer.php') ?>