<?php include('header-first.php') ?>
<title>Leadership - About Our Visionaries | Inxee Systems Private Limited</title>
<meta name="Description"
    content="Mr. Srinath Nudurupati & Mr. Akhil Choudhary are experts in the domain of Electronics and Communication Engineering. Our main intent is to meet innovation-driven industry requirements." />
<meta name="keywords"
    content="Electronics and communication engineering, Mr. Srinath Nudurupati, Mr. Akhil Choudhary, embedded solutions india, embedded electronics development" />
<?php include('header-second.php') ?>
<section class="banner-section">
    <img src="images/Leadership.jpg" alt="Leadership" class="img-responsive">
</section>
<section class="common-section py-3">
    <div class="container">
        <h1 class="mb-3">Leadership</h1>
        <p class="text-justify">Mr. Srinath Nudurupati is a Bachelor of Engineering in the domain of Electronics and
            Communication Engineering. He holds an M.S. degree in Electrical & Computer Engineering from the Clemson
            University, U.S.A. His career started in 1996 at Freescale Semiconductor as a Research and Development
            Engineer. In his professional career spanning about 20 years, he has already held key positions in
            Freescale Semiconductor and Embedded Technology Consultants. He Co-founded Inemsys Technologies, an
            embedded systems firm, in 2009 and went on to become the Founder and Director of Inxee Systems Private
            Limited in 2010. At present, he is the Co-founder and Director of Xinoe Systems pvt ltd. and Director of
            Inxee Systems pvt ltd.
        </p>
        <p class="text-justify">Mr. Nudurupati also holds a number of patents spanning from microprocessors to
            various system technologies and has published a number of technical papers in diverse embedded
            technologies.</p>
        <p class="text-justify">His proficiency in the fields of Embedded Systems ( both Hardware and Software ) in
            Wireless & Wired Communication, Storage, Industrial Automation, Medical & Healthcare, Media &
            Entertainment, Automotive & Defense applications, etc has already made him an acclaimed name in the
            industry.</p>
        <p class="text-justify">Twenty years of cutting-edge technology business experience in high performance
            computing and embedded systems has already led him to develop astute acumen in these domains. With his
            passion to bring about revolutionizing changes in the embedded and semiconductor industry, Mr.
            Nudurupati has become synonymous with many glorious inventions in the past two decades or so. The
            dynamic leader that he is, Mr. Nudurupati always brings out the best from his team. Consequently, we
            take cue from his inspirational ways and keep our high spirits intact to meet innovation-driven industry
            requirements.</p>
        <p class="text-justify">Mr. AKHIL CHOUDHARY is a Bachelor of Engineering in the domain of Electronics and
            Communication Engineering. An alumnus of Delhi College of Engineering, he started his career way back in
            1984 at Uptron India Limited. Having worked there diligently for around two years as a systems
            executive, his sharp business acumen and entrepreneurship skills paved way for the foundation of Binary
            Semantics Limited, which later went on to become a major IT giant in India and a trusted brand overseas.
            He chose to remain Binary Semantics’s director for 9 years spanning from 1986 to 1995, and later donned
            on the cap of CEO in 1995. Currently, he is the CEO of Binary Semantics Limited, as well as the
            Co-founder of Xinoe Systems pvt ltd.</p>
        <p class="text-justify">A well known name in the IT-ITES sector, Mr. Choudhary mirrors the values of the
            organizations he heads. A visionary that he is, Mr. Choudhary believes in prudent work ethics and excels
            in organizational development and software development processes. His commitment and result-oriented
            style of work has won over many admirers from all walks of the technology-driven industry. His
            professional experience of over three decades and down-to-earth demeanour, encourages the entire team to
            perform at par in whichever domain they work in.</p>
    </div>
</section>
<?php include('footer.php') ?>