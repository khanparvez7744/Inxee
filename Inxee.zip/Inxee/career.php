<?php 
require_once("conn.php");
$conn = new dbconn(); 
$pdo= $conn->connect();
   if (isset($_POST['submit'])) {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $location = $_POST['location'];
        $notice = $_POST['notice'];
        $resume = $_FILES['resume']['name'];
        $target_file2 = "./upload/".$resume;
        move_uploaded_file($_FILES["resume"]["tmp_name"], $target_file2);
        $sql = "INSERT INTO career(name,email,phone,location,notice,resume,created_at) values('$name','$email','$phone','$location','$notice','$resume',NOW())";
        if ($pdo -> query($sql)) {
          $to = 'parvez@inxee.com';
          $from = 'info@inxee.com';
          $fromName = 'inxee';
          $subject = "$name is submit his resume";
          $file = "./upload/".$resume;
          $htmlContent = " 
            <table style = 'max-width:600px;width: 100%;'>\r\n\n
              <tr><td>Name</td><td>:</td><td>".$name."</td></tr>\r\n\n
                <tr><td>Email Address</td><td>:</td><td>".$email."</td></tr>\r\n\n
                  <tr><td>Phone</td><td>:</td><td>".$phone."</td></tr>\r\n\n
                    <tr><td>Location</td><td>:</td><td>".$location."</td></tr>\r\n\n
                      <tr><td>Notice Period</td><td>:</td><td>".$notice."</td></tr>\r\n\n
          </table >"; 
          $headers = "From: $fromName"." <".$from.">";
          $semi_rand = md5(time());
          $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";
          $headers.= "\nMIME-Version: 1.0\n". "Content-Type: multipart/mixed;\n". " boundary=\"{$mime_boundary}\"";
          $message = "--{$mime_boundary}\n". "Content-Type: text/html; charset=\"UTF-8\"\n". 
          "Content-Transfer-Encoding: 7bit\n\n".$htmlContent. "\n\n";
      }
    } 
?>
<?php include('header-first.php') ?>
<title>Career With Us – Inxee Systems Private Limited</title>
<meta name="Description"
    content="We are always looking for resources who share our vision of delivering technology to the world through innovation and implementation. Get in touch with Inxee at career@inxee.com with your updated profile and queries." />
<meta name="keywords" content="embedded india, india embedded, indian embedded electronics, embedded software india" />
<?php include('header-second.php') ?>
<section class="banner-section">
    <img src="images/Career with us.jpg" alt="Career with us" class="img-responsive">
</section>
<section class="common-section resume-section py-3">
    <div class="container">
        <h1 class="mb-3">Apply Online</h2>
            <div class="row">
                <div class="col-md-6">
                    <form method="post" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <div class="form-group">
                                    <label for="txtName">Name</label>
                                    <input type="text" class="form-control rounded-0" name="name"
                                        placeholder="Enter Name" required>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <div class="form-group">
                                    <label for="txtEmail">Email</label>
                                    <input type="email" class="form-control rounded-0" name="email"
                                        placeholder="Enter Email" required>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <div class="form-group">
                                    <label for="txtPhone">Phone Number</label>
                                    <input type="text" class="form-control rounded-0" name="phone"
                                        placeholder="Enter Phone Number" required maxlength="10">
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <div class="form-group">
                                    <label for="txtLocation">Current Location</label>
                                    <input type="text" class="form-control rounded-0" name="location"
                                        placeholder="Enter Location" required>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <div class="form-group">
                                    <label for="txtNotice">Notice Period</label>
                                    <input type="text" class="form-control rounded-0" name="notice"
                                        placeholder="Enter Notice Period" required>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <div class="form-group">
                                    <label for="txtResume">Attach Resume</label>
                                    <input type="file" name="resume" />
                                </div>
                            </div>

                        </div>
                        <button type="submit" class="btn btn-shutter-more btn-shutter-more2 text-uppercase"
                            name="submit">Submit</button>
                        <?php
              if(@$mail){
                echo"<div class='center'><span class='mt-5' style='text-align:center; background-color:green;color:white;overflow:hidden;'>Thank You!!! We Will Get Back You Soon</span></div>";
              }
            ?>
                    </form>

                </div>
                <div class="col-md-6">
                    <img src="images/careers2.png" alt="career" class="img-responsive">
                </div>
            </div>
    </div>
</section>
<?php include('footer.php') ?>