<?php include('header-first.php') ?>
<title>Embedded Software - IoT | Design In India. Make In India | Inxee Systems Private Limited</title>
<meta name="Description"
    content="Semiconductors have had a massive impact on our society since the time they were discovered. We have rich R&D experiences in ASIC, FPGA & IP Development." />
<meta name="keywords"
    content="semiconductor devices, semiconductor development process, semiconductor development company, semiconductor development kits, semiconductor r&d fields" />
<?php include('header-second.php') ?>
<section class="banner-section">
    <img src="images/Embedded Software.jpg" alt="Embedded Software" class="img-responsive">
</section>
<section class="common-section py-3">
    <div class="container">
        <h1 class="mb-3">Embedded Software</h1>
        <p class="text-justify">Embedded software is written to control the functionality of embedded systems as desired
            in a particular application. Unlike application software, embedded software has fixed hardware requirements
            and capabilities wherein addition of outside hardware or software is strictly controlled. Embedded software
            is bounded by memory and time constraints and sometimes maybe interchangeably used with firmware.</p>
        <p class="text-justify">Firmware in electronic systems means the combination of memory, program code and data.
            The firmware contained in devices such as computers and computer peripherals, mobile phones, digital cameras
            and embedded systems such as traffic lights, consumer appliances etc provides the control program for the
            device. Non-volatile memory devices such as ROM, EPROM or Flash Memory generally holds firmware.</p>

        <h2 class="mb-2 mt-3">We have successfully worked on an array of embedded softwares and firmwares as listed below:
        </h2>
        <ol>
            <li>Firmware development platforms — [ARM, x86, MIPS, PowerPC, DSPs, various microcontroller families]</li>
            <li>Real-time/Embedded OS platforms — [QNX, VxWorks, RTLinux, eCos, LynxOS, FreeRTOS, OSEK,Symbian, Windows
                cE/Mobile, Embedded Linux,Android, BREW, IphoneOS, BlackberryOS]
            </li>
            <li>Multimedia Codecs & Containers — [MP3, WMA, Vorbis, Speex, AMR, AC3, RealAudio,MPEG2, MPEG4/H.264,
                Motion JPEG2000, WMV, RealVideo,JPEG, PNG, JPEG2000, GIF, BMP,AVI, FLV, MP4, QuickTime, RealMedia, WAV]
            </li>
            <li>Wireless & Wireline protocols — [LTE, WiMax, GSM, GPRS, GPS, 3G, WiFi, EnOcean, RFID, UWB, Bluetooth,
                Zigbee,10/100/1000/10G Ethernet, SONET/SDH]
            </li>
            <li>Storage protocols — [Serial ATA, SAS, SCSI, RAID, ESCON, Fibre channel, iSCSI, Infiniband,
                Hypertransport, RapidIO, NFS/CIFS over GbE, RDMA]
            </li>
            <li>Network protocols — [TCP/IP, UDP, RTP, RTSP, Gstreamer]
            </li>
            <li>Board support packages — [Bootloaders: U-Boot/RedBoot/EBOOT, Device drivers, Protocol stacks, System
                interfaces, Memory, File system, Diagnostics]
            </li>
            <li>Application software development — [Specification development,GUI, Open source, custom
                development,Testing,Software porting, Software integration,Software re-engineering,Software
                testing,Platforms: Flash/Java/.Net/Ajax/Web frameworks]
            </li>
        </ol>
    </div>
</section>
<?php include('footer.php') ?>