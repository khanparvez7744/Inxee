<?php include('header-first.php') ?>
<title>Smart Automation - IoT | Design In India. Make In India | Inxee Systems Private Limited</title>
<meta name="Description"
    content="Inxee has taken up projects which caters to various parts of Smart and Connected Cities." />
<meta name="keywords" content="smart homes, smart home devices, smart solutions, internet of things, iot" />
<?php include('header-second.php') ?>
<section class="banner-section">
    <img src="images/Smart-Automation.jpg" alt="smart Automation" class="img-responsive">
</section>
<section class="common-section py-3">
    <div class="container">
        <h1 class="mb-3">Smart Automation</h1>
        <p class="text-justify">Automation is the process of using devices and machines along with information
            technology to control systems and optimize efficiency and productivity and ensure quality products and
            services delivered on time. Homes, office spaces , manufacturing plants, industries, banks, educational
            organizations, shopping complexes, parking lots, etc are an array of places where smart automation can come
            handy.</p>
        <p class="text-justify">Enabling software to control machines and m2m communication would indeed make the
            automation swift and smart. Unforeseen errors often caused due to human labor can also be reduced when we
            use smart automation. The best part is the ease with which you would be able to control all action with a
            few clicks and that too from a remote location.</p>

    </div>
</section>
<?php include('footer.php') ?>