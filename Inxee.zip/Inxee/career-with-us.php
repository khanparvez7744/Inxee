<?php include('header-first.php') ?>
<title>Career With Us – Inxee Systems Private Limited</title>
<meta name="Description"
    content="We are always looking for resources who share our vision of delivering technology to the world through innovation and implementation. Get in touch with Inxee at career@inxee.com with your updated profile and queries." />
<meta name="keywords" content="embedded india, india embedded, indian embedded electronics, embedded software india" />
<?php include('header-second.php') ?>
<style>
.boder {
    border: 1px solid #dfdfdf;
    margin: 15px 0;
    padding: 20px
}

.CarExpe {
    margin: 20px 0;
}

.CarExpe .exp {
    margin-left: -12px
}


.mt-0 {
    margin-top: 0;
}
</style>
<section class="banner-section">
    <img src="images/Career with us.jpg" alt="Career with us" class="img-responsive">
</section>
<section class="common-section career-section py-3">
    <div class="container">
        <h1 class="mb-3">Career With Us</h2>
            <p class="text-justify">INXEE is a team of talented individuals from all corners of the world dedicated to
                help create a world where technology finds a way to transform our lives for a better tomorrow. One thing
                that can greatly escalate achievement among individuals, teams and organizations is finding the correct
                direction to proceed. As a continuously evolving company, Inxee is always looking for resources who
                share our vision of delivering technology to the world through innovation and implementation.</p>
            <p class="text-justify">We offer a unique and dynamic work environment - a culture that balances
                professionalism with lively interactions and healthy competition. Inxee is a place for people with
                progressive sight and enthusiasm to excel and offers great opportunities for professional growth and
                satisfaction for those who work hard and are willing to learn, unlearn and relearn, thus making it a
                continuous process. We value cultural and lingual diversity which shows in our valued team of
                professionals.</p>
            <p class="text-justify">All qualified applicants will receive consideration for employment without any
                regard to race, religion, color, creed, gender, nationality, age, disability or any other legally
                protected basis.</p>
            <p class="text-center mt-4">
                <img src="images/hiring.png" alt="Hiring" class="">
            </p>
            <div class="boder">
                <div class="row">
                    <div class="col-sm-8">
                        <h2>PCB Design Engineer</h2>
                    </div>
                    <div class="col-sm-4">
                        <a href="career.php">
                            <span class="btn btn-shutter-more btn-shutter-more2 text-uppercase pull-right mt-0">Apply
                                Now</span>
                        </a>
                    </div>
                </div>
                <div class="row CarExpe">
                    <div class="col-sm-2">
                        <div class="exp"><i class="fa fa-briefcase"></i> 1-7 years</div>
                    </div>
                    <div class="col-sm-3">
                        <div><i class="fa fa-map-marker"></i> Gurgaon, Haryana</div>
                    </div>
                    <div class="col-sm-3">
                        <div><i class="fa fa-graduation-cap"></i> B-Tech/B.E/M-Tech</div>
                    </div>
                    <div class="col-sm-4"></div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <h3>Job Description - </h3>
                        <p class="text-justify">Working as part of a team, under the direction of the PCB Design Lead
                            Engineer/HW Manager.</p>
                        <ol id="listJDPCB">
                            <li>Should have Extensive knowledge in using Allegro 16.3 schematic capture and layout
                                creation layout tools.
                            </li>
                            <li>Should have Experience with ERP systems, BOM structures
                            </li>
                            <li>PCB layout experience within a design role
                            </li>
                            <li>High speed layout techniques for differential pair and serial communications
                            </li>
                            <li>Experience in RF circuit layout and laminates
                            </li>
                            <li>Design single sided, double sided and multi-layered PCB's using industry standard
                                techniques.
                            </li>
                            <li>Design & develop Schematics. CAD library administration including symbol, footprint
                                generation and database administration
                            </li>
                            <li>Creation and maintenance of BOM, Inventory and Production logistics
                            </li>
                            <li>Creation of 3D models and assemblies from 2D layouts
                            </li>
                            <li>Liaising closely with other engineers to create robust designs
                            </li>
                            <li>Liaising with the team and vendor for procurement and transfer of documentation
                            </li>
                            <li>Contributing to continual process improvement within the PCB layout function
                            </li>
                            <li>Experience in Analog circuit layout, Manipulation of Gerber files
                            </li>


                        </ol>
                        <span class="btn btn-shutter-more btn-shutter-more2 text-uppercase  " id="btnJDPCB">Read
                            More</span>
                    </div>
                </div>
            </div>
            <div class="boder">
                <div class="row">
                    <div class="col-sm-8">
                        <h2>Embedded Software Engineer</h2>
                    </div>
                    <div class="col-sm-4"> <a href="career.php"><span
                            class="btn btn-shutter-more btn-shutter-more2 text-uppercase pull-right mt-0"
                            data-toggle="modal" data-target="#careerModal">Apply
                            Now</span></a></div>
                </div>
                <div class="row CarExpe">
                    <div class="col-sm-2">
                        <div class="exp"><i class="fa fa-briefcase"></i> 1-7 years</div>
                    </div>
                    <div class="col-sm-3">
                        <div><i class="fa fa-map-marker"></i> Gurgaon, Haryana</div>
                    </div>
                    <div class="col-sm-3">
                        <div><i class="fa fa-graduation-cap"></i> B-Tech/B.E/M-Tech</div>
                    </div>
                    <div class="col-sm-4"></div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <h3>Job Description - </h3>
                        <p class="text-justify">Working as part of a team, under the direction of the Embedded Software
                            Lead
                            Engineer/HW Manager.</p>
                        <ol id="listJDEmbed">
                            <li>Working knowledge of Linux, freeRTOS and other RTOS.</li>
                            <li>Work experience of TCP/IP, GPRS, GSM, Wi-Fi, Bluetooth, Zigbee and LORA module.</li>
                            <li>Sound knowledge of ADC, DAC, PWM, Touchscreen, GLCD, Graphics Library Integration.
                            </li>
                            <li>Design and implement software of embedded devices and systems.
                            </li>
                            <li>Design, document, develop, code, test and debug system software.
                            </li>
                            <li>Analyse and enhance efficiency, stability and scalability of system resources.
                            </li>
                            <li>Interface with hardware design and development.</li>
                            <li>Strong in embedded C and Data structure programming.
                            </li>
                            <li>Should have hands-on experience with ARM, AVR, PIC & ST microcontrollers.
                            </li>
                            <li>Sound knowledge of various communication interfaces like SPI, UART, I2C, Modbus, CAN and
                                USB.
                            </li>
                        </ol>
                        <span class="btn btn-shutter-more btn-shutter-more2 text-uppercase  " id="btnJDEmbed">Read
                            More</span>
                    </div>
                </div>
            </div>
    </div>
</section>
<script>
$(document).ready(function() {
    $("#listJDPCB").hide();
    $("#btnJDPCB").click(function() {
        $("#listJDPCB").toggle();
        $(this).text($(this).text() == 'Hide' ? 'Read More' : 'Hide');
    });
    $("#listJDEmbed").hide();
    $("#btnJDEmbed").click(function() {
        $("#listJDEmbed").toggle();
        $(this).text($(this).text() == 'Hide' ? 'Read More' : 'Hide');
    });
});
</script>
<?php include('footer.php') ?>