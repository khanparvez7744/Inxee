<?php 
require_once("conn.php");
$conn = new dbconn(); 
$pdo= $conn->connect();
if(isset($_POST['submit'])){
    $name= $_POST['name'];
    $company= $_POST['company'];
    $email= $_POST['email'];
    $mobile= $_POST['phone'];
    $msg = $_POST['message'];
    $sql="INSERT INTO contact(name,company,email,phone,message,create_at) values('$name','$company','$email','$mobile','$msg',NOW())";
    if($pdo->query($sql)){
$to = 'parvez@inxee.com'; 
$from = 'info@inxee.com';
$fromName = 'Inxee Contact'; 
$subject = "New Query From $name";  
$message = " 
    <table style='max-width:600px;width: 100%;'>\r\n\n
        <tr><td>Name</td><td>:</td><td>".$name."</td></tr>\r\n\n
        <tr><td>Company</td><td>:</td><td>".$company."</td></tr>\r\n\n
        <tr><td>Email Address</td><td>:</td><td>".$email."</td></tr>\r\n\n
         <tr><td>Mobile</td><td>:</td><td>".$mobile."</td></tr>\r\n\n
         <tr><td>Message</td><td>:</td><td>".$msg."</td></tr>\r\n\n
         </table>
"; 
$headers = "From: $fromName"." <".$from.">"; 
$headers   .= "MIME-Version: 1.0\r\n";
$headers   .= "Content-type: text/html; charset=utf-8\r\n";
$mail = @mail($to, $subject, $message, $headers);  
echo "<script type='text/javascript'>
</script>";
 }
 }
?>
<?php include('header-first.php') ?>
<title>Contact Us - India | United States - Inxee Systems Private Limited</title>
<meta name="Description"
    content="Inxee has its development centers in Gurgaon - India & United States. Want to know more about us at Email: info@inxee.com" />
<meta name="keywords" content="embedded india, india embedded, indian embedded electronics, embedded software india" />
<?php include('header-second.php') ?>
<section class="banner-section">
    <img src="images/Contact us.jpg" alt="Contact Us" class="img-responsive">
</section>
<section class="common-section cont-section pt-3">
    <div class="container">
        <h1 class="mb-3">Contact Us</h1>
        <div class="row">
            <div class="col-md-6">
                <p>We are always looking to have interesting discussions with you. Feel free to reach out to us
                    directly if you have any ideas, comments, or feedback.</p>
                <h3 class="mt-3 mb-3"><img src="images/india-flag.png" alt="flag"> India Office:</h3>
                <p>Plot No.144, Udyog Vihar Phase-I,
                    Sector-20, Gurgaon-122016, Haryana</p>
                <p>Phone - 0124-4488856</p>
                <p>Email - info@inxee.com</p>
                <h3 class="mt-3 mb-3"><img src="images/united-states-flag.png" alt="united states flag"> United States
                    Office:</h3>
                <p>7 Lincoln Highway, Suite 205, Edison, NJ-08820</p>
                <p>Phone - 732-548-9268</p>
                <p>Email - info@inxee.com</p>
            </div>
            <div class="col-md-6">
                <form method="post">
                    <div class="row">
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label for="txtName">Name</label>
                                <input type="text" class="form-control rounded-0"  placeholder="Enter Name"
                                    name="name" required>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label for="txtCompany">Company</label>
                                <input type="text" class="form-control rounded-0" 
                                    placeholder="Enter Company" name="company" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="txtEmail">Email</label>
                                <input type="email" class="form-control rounded-0"
                                    placeholder="Enter Email" name="email" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="txtPhone">Phone Number</label>
                                <input type="text" class="form-control rounded-0" 
                                    placeholder="Enter Phone" name="phone" maxlength="10" required>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="txtMessage">Your message</label>
                                <textarea class="form-control rounded-0" placeholder="How can we be of service?"
                                    name="message"></textarea>
                            </div>
                        </div>
                    </div>
                    <button type="submit" name="submit"
                        class="btn btn-shutter-more btn-shutter-more2 text-uppercase">Submit</button>
                </form>
                <?php
                if(@$mail){
                    echo"<div class='center'><span class='mt-5' style='text-align:center; background-color:green;color:white;overflow:hidden;'>Thank You!!!We Will Get Back You Soon</span></div>";
                  }
                   
                ?>
            </div>
        </div>
    </div>
    <div class="mt-5">
        <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3505.9689538188204!2d77.07858401507987!3d28.51058178246611!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d195d982ffc3f%3A0x106c4552c02facd0!2sInxee+Systems+Private+Limited!5e0!3m2!1sen!2sin!4v1486976581009"
            width="100%" frameborder="0" style="border:0"></iframe>
    </div>
</section>
<?php include('footer.php') ?>