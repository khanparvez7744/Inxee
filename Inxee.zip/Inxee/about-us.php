<?php include('header-first.php') ?>
<title>About Us - IoT | Hardware & Software | Embedded Electronics | Semiconductors | Inxee Systems Private Limited
</title>
<meta name="Description"
    content="Inxee is an international technology-centric Embedded Hardware and Software Services company of experience with expertise in IoT technology." />
<meta name="keywords"
    content="embedded electronics company, embedded system development company, r&d services company, embedded product development company" />
<?php include('header-second.php') ?>
<section class="banner-section">
    <img src="images/About-us.jpg" alt="about us" class="img-responsive">
</section>
<section class="common-section py-3">
    <div class="container">
        <h1 class="mb-3">About Us</h2>
            <p class="text-justify">Inxee Systems Pvt Ltd is an embedded technology-centric Design House
                and Manufacturing company head-quartered in Delhi-NCR, India. Inxee has completed many
                successful projects in the domains of Automation, Automotive, Medical, Consumer and
                Defense Electronics. Inxee is currently creating products and executing turn-key
                projects in various Internet Of Things (IoT) applications such as – Smart City, Smart
                Home, Smart Factory, Smart Healthcare and Smart Wearables/Trackers.</p>
            <p class="text-justify">Inxee is creating waves in the Embedded-IoT Technology R&D services
                and product landscape, and has designed, manufactured and deployed embedded hardware and
                software products that are reliable. We at Inxee believe that the Internet Of Things is
                bringing a transformational shift to the world as we know. IoT has the potential to be
                the engine that powers our economy for decades to come. We now build IoT products and
                provide services to partners to help deliver IoT solutions that are reliable,
                intelligent and ubiquitous. With the IoT market demanding fast development and
                deployment cycles, Inxee is shedding traditional industry practices and putting together
                generic IoT solutions in the form of SMART PCB modules, that can be quickly customized
                to the target applications.</p>
            <p class="text-justify">Inxee offers a broad spectrum of solutions in design & development
                under the fields of PCB, Embedded Software & Systems. Inxee provides design,
                manufacturing, installation and maintenance services support to its partners with its
                services spanning across individual hardware and software components to entire systems.
                We are experts in an array of embedded platforms -- hardware technologies and embedded
                programming skill sets.</p>
            <p class="text-justify">Above and beyond, not only is Inxee an innovation-driven company but
                is also an organization that strives to build a prosperous ecosystem with its partners.
                Together we strive to empower people, build a better world with a better connected
                society - all this through “Design in India, Make In India” !</p>
    </div>
</section>
<?php include('footer.php') ?>