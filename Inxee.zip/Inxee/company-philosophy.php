<?php include('header-first.php') ?>
<title>Vision - Next Generation IoT Services Provider | Inxee Systems Private Limited</title>
<meta name="Description"
    content="Our philosophy to be INXEE as a generation-next services provider that offers all kinds of transformational and innovative embedded and semiconductor solutions." />
<meta name="keywords"
    content="indian embedded services,  vlsi design services, embedded services india, next generation services provider, system design india, electronics services india" />
<?php include('header-second.php') ?>
<section class="banner-section">
    <img src="images/Company & philosophy.jpg" alt="Company & philosophy" class="img-responsive">
</section>
<section class="common-section py-3">
    <div class="container">
        <h1 class="mb-3">Company Philosophy</h1>
            <h2 class="mb-2">Vision</h2>
            <p class="text-justify">We aspire to see INXEE as a generation-next "Internet Of Things" services provider
                that
                offers all kinds of transformational and innovative embedded ( software and hardware ) and semiconductor
                solutions to the world's best companies, apart from leading revolutionary inventions. We want to build a
                company that clients and customers think of whenever they are faced with unprecedented industry-related
                problems. We desire not just to be different but to be the worthy best.

            </p>
            <h2 class="mb-2 mt-3">Mission</h2>
            <p class="text-justify">To create a much more innovative, productive and resourceful Inxee so that we can
                bring
                the best technologies at your helm and make your life easier and the world a better place to live in.
                Being
                a solution-oriented ESDM innovator is what we strive to be.</p>
            <h2 class="mb-2 mt-3">Values and Virtues</h2>
            <p class="text-justify">We are a strong contingent of high calibre and dedicated professionals who work with
                utmost care to meet the requirements of our clients in time. We never compromise with the quality of
                services we deliver. We are a close-knit team which works relentlessly to exceed expectations and
                deliver
                exceptional services. We abide by ethical manoeuvres while working on our diverse projects. This sturdy
                foundation fosters teamwork that enables us to serve our customers and partners with zeal and zest. We
                take
                complete accountability for our work and keep our approach flexible and collaborative.</p>
    </div>
</section>
<?php include('footer.php') ?>