<?php include('header-first.php') ?>
<title>News and Events - IoT | Design In India. Make In India - Inxee Systems Private Limited</title>
<meta name="Description"
    content="Inxee has their development centers in Gurgaon - India & United States." />
<meta name="keywords"
    content="iot, embedded india, india embedded, indian embedded electronics, embedded software india" />
<?php include('header-second.php') ?>
<section class="banner-section">
    <img src="images/News & Events.jpg" alt="News & Events" class="img-responsive">
</section>
<section class="common-section py-3">
    <div class="container">
        <h1 class="mb-3">News and Events</h1>
        <div class="row">
            <div class="col-sm-6">
                <h3 class="mt-2 mb-2">INXEE Hosts Industrial Tour For Dronacharya College Of Engineering</h3>
                <img src="images/internship.jpg" alt="internship" class="img-responsive rounded">
            </div>
            <div class="col-sm-6">
                <h3 class="mt-2 mb-2">INXEE launches GWATCH- a GPS enabled personal tracking smart watch</h3>
                <img src="images/gwatch.jpg" alt="gwatch" class="img-responsive rounded">
            </div>
            <div class="col-sm-6">
                <h3 class="mt-4 mb-2">Witness The TechWorld Like Never Before As Inxee Invites You To Be A Part Of
                    Convergence/ 2nd Internet Of Things Expo 2018, 7-9 March @ Pragati Maidan: Hall #7B, Booth no #7B15
                </h3>
                <img src="images/iotIndiaExpo.jpg" alt="iot india expo" class="img-responsive rounded">
            </div>
            <div class="col-sm-6">
                <h3 class="mt-4 mb-2">INXEE invites all technology enthusiasts to witness the mega electronics expo -
                    EFY 2015 scheduled from Feb 26th through Feb 28th, and visit our Expo Booth no-M2</h3>
                <img src="images/efyEvent.jpg" alt="efy event" class="img-responsive rounded">
            </div>
        </div>

    </div>
</section>
<?php include('footer.php') ?>